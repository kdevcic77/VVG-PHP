<?php 
	print '
	<section id="topnews">

						<div class="container">
							<div class="banner-inner">
								<img src="images/banner.jpg">
							</div>
							<h1>Top news</h1>
							<p class="green">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet rutrum metus nec mollis. Suspendisse potenti. Quisque elementum id tellus pulvinar porttitor. Sed magna arcu, dapibus et varius sit amet, euismod sit amet risus. Duis sit amet tincidunt augue. Duis et quam egestas, mollis est tincidunt, posuere tellus. Morbi a suscipit ex.</p>
							<p class="yellow">Pellentesque sit amet eleifend ex. Vestibulum euismod ligula a elit mattis vestibulum sed non augue. Ut nibh magna, efficitur ac rhoncus sed, ultrices id lacus. In feugiat ornare justo, vitae pellentesque sapien gravida eu. Nulla cursus ante vitae ligula iaculis placerat. Quisque lobortis porta enim.</p>
							<figure>
								<img id="news-big" src="images/news.jpg" alt="News" title="news-big">
							</figure>
							<p class="yellow">Suspendisse gravida malesuada fringilla. Nunc ornare sagittis porta. Nullam et quam mi. Donec facilisis lectus id risus tristique vulputate. Sed a malesuada ex. Donec id quam elit. Suspendisse potenti. Fusce facilisis id ex eget finibus.</p>
						</div>
	</section>
	<section id="boxnews">
						<div class="container">
							<div class="box">
							<figure id="politics">
							<img src="images/politics.jpg">
							</figure>
							<h3>Politics</h3>
							<p>Suspendisse potenti. Quisque elementum id tellus pulvinar porttitor.</p>
							</div>
							<div class="box">
							<figure id="showbiz">
							<img src="images/showbiz.jpg">
							</figure>
							<h3>Showbusiness</h3>
							<p>Suspendisse potenti. Quisque elementum id tellus pulvinar porttitor.</p>
							</div>
							<div class="box">
							<figure id="sport">
							<img src="images/sport.jpg">
							</figure>
							<h3>Sports</h3>
							<p>Suspendisse potenti. Quisque elementum id tellus pulvinar porttitor.</p>
							</div>
						</div>
	</section>';
?>