<?php 
	print '
	<div class="container">
					<section class="main-about">
						<h1>About Us</h1>
							<p class="normal">
							Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed porta, massa ac sodales tincidunt, ante lorem bibendum ligula, in ornare ex tortor ac dolor. Ut dui mi, condimentum et ipsum sit amet, gravida sodales dolor. Duis rutrum sed orci ac fringilla. Nulla pretium a magna id venenatis. Etiam pretium ornare mauris vel consectetur. Maecenas eros dui, convallis sed lacus at, vestibulum faucibus magna. Suspendisse in ornare tortor. 
							</p>
							<p class="green">
							Maecenas ornare leo a tellus ornare viverra. Aliquam sed metus a felis convallis rutrum. Curabitur viverra convallis nisl et faucibus. Curabitur vitae dictum dui, ac sagittis leo. Curabitur eget lectus at nisi bibendum accumsan ac in sapien. Suspendisse volutpat est eget diam fringilla aliquet. Praesent id mi diam.
							</p>
							<figure class="veleuciliste">
								<img src="images/veleuciliste.jpg" alt="VVG" title="VVG">
								<figcaption>Pellentesque sit amet eleifend ex. Vestibulum euismod ligula a elit mattis vestibulum sed non augue. Ut nibh magna, efficitur ac rhoncus sed, ultrices id lacus. In feugiat ornare justo, vitae pellentesque sapien gravida eu. Nulla cursus ante vitae ligula iaculis placerat. Quisque lobortis porta enim.</figcaption>
							</figure>
						<h1>What we do</h1>
							<p class="yellow">
								Suspendisse gravida malesuada fringilla. Nunc ornare sagittis porta. Nullam et quam mi. Donec facilisis lectus id risus tristique vulputate. Sed a malesuada ex. Donec id quam elit. Suspendisse potenti. Fusce facilisis id ex eget finibus.</p>
							<p class="green">Ut vitae fringilla metus, at placerat metus. Morbi libero orci, interdum non interdum non, ullamcorper eu justo. Duis dictum, metus vel bibendum varius, risus ligula vestibulum mi, nec accumsan lectus risus vel mi. Sed eget arcu a odio fringilla scelerisque a et lorem. Proin egestas vestibulum libero, vel efficitur ante vulputate ut. Ut aliquet lectus a faucibus ullamcorper. Vestibulum quis dictum sapien. Sed sed maximus nisi. Phasellus a ultricies mauris. Praesent ut enim ac ex convallis dapibus.</p>
					</section>
					<section>
					<iframe width=100% height="480" src="https://www.youtube.com/embed/FZFNaXgG8-g" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen>Your browser does not support the video tag.</iframe>
					</section>
	</div>';
?>